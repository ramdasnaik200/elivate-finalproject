from flask import Flask, render_template, request
import subprocess
import os
import glob

app = Flask(__name__, static_url_path='/static', static_folder="scanner_reports")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        results_dir = "scanner_reports"
        wapiti_output_folder = os.path.join(results_dir, "wapiti_output")
        os.makedirs(wapiti_output_folder, exist_ok=True)

        owasp_report_path = os.path.join(results_dir, "owaspcheck_report.txt")
        nikto_report_path = os.path.join(results_dir, "nikto_report.txt")

        # Default outputs
        owasp_output = "No OWASPCheck output found."
        nikto_output = "No Nikto output found."
        wapiti_report = "No Wapiti report generated."

        # ----------------- Run OWASPCheck -----------------
        try:
            result = subprocess.run(
                ['python', 'OWASPCheck/owaspcheker.py', '-t', url, '-o', owasp_report_path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            if os.path.exists(owasp_report_path):
                with open(owasp_report_path, 'r', encoding='utf-8') as f:
                    owasp_output = f.read()
            else:
                owasp_output = f"OWASPCheck did not create report file.\n\nSTDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}"
        except Exception as e:
            owasp_output = f"Error running OWASPCheck: {e}"

        # ----------------- Run Wapiti -----------------
        
                
        try:
            # Step 1: Clean up old reports
            for file in glob.glob(os.path.join(wapiti_output_folder, "*.html")):
                os.remove(file)
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            # Step 2: Run Wapiti
            result = subprocess.run(
                ['wapiti', '-u', url, '-f', 'html', '-o', wapiti_output_folder],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                env=env
            )

            print("Wapiti STDOUT:", result.stdout)
            print("Wapiti STDERR:", result.stderr)

            # Step 3: Load the new report
            wapiti_files = sorted(
                glob.glob(os.path.join(wapiti_output_folder, "*.html")),
                key=os.path.getmtime,
                reverse=True
            )

            if wapiti_files:
                latest_file = wapiti_files[0]
                filename = os.path.basename(latest_file)
                wapiti_report = f"/static/wapiti_output/{filename}"

                # ✅ Patch kube.min.css to white background
                kube_css_path = os.path.join(wapiti_output_folder, "kube.min.css")
                if os.path.exists(kube_css_path):
                    with open(kube_css_path, "r", encoding="utf-8") as f:
                        css_content = f.read()

                    css_content = css_content.replace("background:#111", "background:#fff")
                    css_content = css_content.replace("color:#eee", "color:#000")

                    with open(kube_css_path, "w", encoding="utf-8") as f:
                        f.write(css_content)
                
            else:
                wapiti_report = "Error: Wapiti did not generate any HTML report.\n\nSTDERR:\n" + result.stderr

        except Exception as e:
            wapiti_report = f"Error running Wapiti: {e}"


        # ----------------- Run Nikto (instead of Nettacker) -----------------
        try:
            nikto_path = r"nikto/nikto.pl"
            nikto_config = r"nikto/nikto.conf"

            result = subprocess.run(
                ["perl", nikto_path, "-config", nikto_config, "-h", url, "-output", nikto_report_path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )

            if os.path.exists(nikto_report_path):
                with open(nikto_report_path, 'r', encoding='utf-8') as f:
                    nikto_output = f.read()
            else:
                nikto_output = f"Nikto did not produce output.\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        except Exception as e:
            nikto_output = f"Error running Nikto: {e}"

        return render_template("report.html",
                                url=url,
                                owasp_output=owasp_output,
                                nikto_output=nikto_output,
                                wapiti_report=wapiti_report)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
