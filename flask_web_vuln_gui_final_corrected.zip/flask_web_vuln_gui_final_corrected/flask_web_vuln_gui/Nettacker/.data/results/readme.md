### Nettacker's results path
