### Nettacker's data path
