People who helped to create the OWASP Nettacker. You can see the complete list of Developers on [OpenHub](https://www.openhub.net/p/OWASP-Nettacker/contributors) and [GitHub](https://github.com/OWASP/Nettacker/graphs/contributors) contributors.

### Leaders & Mentors
* [Ali Razmjoo Qalaei](mailto:ali.razmjoo@owasp.org)
* [Arkadii Yakovets](mailto:arkadii.yakovets@owasp.org)
* [Sam Stepanyan](mailto:sam.stepanyan@owasp.org)
* [Sri Harsha Gajavalli](mailto:sriharsha.g@owasp.org)



### Contributors
* [Shaddy Garg](mailto:shaddygarg1@gmail.com)
* [Pradeep Jairamani](mailto:pradeepjairamani22@gmail.com)
* [Hannah Brand](mailto:bran0793@umn.edu)
* [Vahid Behzadan](mailto:behzadan@ksu.edu)
* [Mohammad Reza Zamiri](mailto:mr.zamiri@ieee.org)
* [Mojtaba MasoumPour](mailto:mojtaba6892@gmail.com)
* [Ehsan Nezami](mailto:ehsan.empire1@gmail.com)
* [camel32bit](https://github.com/camel32bit)
* [Ravindra Sharma](mailto:sha.ravindra1307@gmail.com)
* [Harshavardhan Reddy](mailto:harsha010@outlook.com)
* [ArianPH](mailto:pandkhahiarian@gmail.com)
* [omdmhd](mailto:om.mo1375@gmail.com)
* [Mahdi Rasouli](mailto:mahdirasouli007@gmail.com)
* [Tikam Singh Alma](mailto:timonalma81@gmail.com)
* [Jecky](mailto:ht974@nyu.edu)
* [VictorSuraj](https://github.com/VictorSuraj)
* [Clarence Cromwell](mailto:clarencewcromwell@gmail.com)
* [Aman Gupta](mailto:aman.gupta@owasp.org)
* [Kunal Khandelwal](mailto:khandelwal.kunal4@gmail.com)
* [Pinaki Mondal aka 0xInfection](https://github.com/0xInfection) 
* [Divyansh Jain](https://github.com/itsdivyanshjain)
* [Akshay Behl](https://github.com/Captain-T2004)
* **[FULL LIST](https://github.com/OWASP/Nettacker/graphs/contributors)**



The OWASP Nettacker Project Team is very grateful to Google's Summer of Code (GSoC - summerofcode.withgoogle.com) and to all GSoC students who helped to enhance Nettacker while working during their summer break!