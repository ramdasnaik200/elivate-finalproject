"""Nettacker main.py."""

from nettacker.core.app import Nettacker


def run():
    app = Nettacker()
    app.run()
