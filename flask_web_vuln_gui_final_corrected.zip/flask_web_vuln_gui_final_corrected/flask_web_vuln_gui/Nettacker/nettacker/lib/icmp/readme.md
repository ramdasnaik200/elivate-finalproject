License
######
https://gist.github.com/pklaus/856268

https://github.com/corentone/python3-ping/blob/master/ping.py

changes credit: Ali Razmjoo - OWASP Nettacker