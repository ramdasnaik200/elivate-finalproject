OWASP Nettacker Payloads
=====================================

OWASP Nettacker payloads are located here

### Passwords
* https://github.com/danielmiessler/SecLists/blob/master/Passwords/Common-Credentials/10-million-password-list-top-1000.txt


### User-Agents
* Web Browser User agents