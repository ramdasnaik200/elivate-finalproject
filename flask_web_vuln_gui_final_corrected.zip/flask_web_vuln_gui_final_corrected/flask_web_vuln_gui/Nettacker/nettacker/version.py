"""Nettacker version."""

__version__ = "0.4.0"
__version_tuple__ = (0, 4, 0)
__release_name__ = "QUIN"
