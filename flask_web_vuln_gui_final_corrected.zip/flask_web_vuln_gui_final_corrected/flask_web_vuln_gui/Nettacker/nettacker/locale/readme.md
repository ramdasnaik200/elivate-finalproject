OWASP Nettacker Language Library
================================

OWASP Nettacker message libraries stored in here.